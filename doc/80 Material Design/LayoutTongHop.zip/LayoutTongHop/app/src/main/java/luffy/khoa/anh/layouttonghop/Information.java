package luffy.khoa.anh.layouttonghop;

/**
 * Created by khoa on 7/27/16.
 */
public class Information {
        public int imageId;
        public String title;
}
